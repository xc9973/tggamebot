-- 003_create_daily_stats_view.down.sql
-- Drop daily game stats view

DROP VIEW IF EXISTS daily_game_stats;
