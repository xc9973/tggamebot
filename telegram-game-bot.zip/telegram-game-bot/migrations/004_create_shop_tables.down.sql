-- Drop Shop System Tables
DROP INDEX IF EXISTS idx_daily_purchases_date;
DROP TABLE IF EXISTS daily_purchases;
DROP INDEX IF EXISTS idx_handcuff_locks_expires;
DROP TABLE IF EXISTS handcuff_locks;
DROP TABLE IF EXISTS user_items;
